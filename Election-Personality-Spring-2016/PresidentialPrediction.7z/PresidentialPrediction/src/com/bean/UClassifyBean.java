package com.bean;

public class UClassifyBean {

	private int id;
	
	private int feeling;
	
	private int thinking;
	
	private int extraversion;
	
	private int introversion;
	
	private int judging;
	
	private int perceiving;
	
	private int sensing;
	
	private int intution;

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the feeling
	 */
	public int getFeeling() {
		return feeling;
	}

	/**
	 * @param feeling the feeling to set
	 */
	public void setFeeling(int feeling) {
		this.feeling = feeling;
	}

	/**
	 * @return the thinking
	 */
	public int getThinking() {
		return thinking;
	}

	/**
	 * @param thinking the thinking to set
	 */
	public void setThinking(int thinking) {
		this.thinking = thinking;
	}

	/**
	 * @return the extraversion
	 */
	public int getExtraversion() {
		return extraversion;
	}

	/**
	 * @param extraversion the extraversion to set
	 */
	public void setExtraversion(int extraversion) {
		this.extraversion = extraversion;
	}

	/**
	 * @return the introversion
	 */
	public int getIntroversion() {
		return introversion;
	}

	/**
	 * @param introversion the introversion to set
	 */
	public void setIntroversion(int introversion) {
		this.introversion = introversion;
	}

	/**
	 * @return the judging
	 */
	public int getJudging() {
		return judging;
	}

	/**
	 * @param judging the judging to set
	 */
	public void setJudging(int judging) {
		this.judging = judging;
	}

	/**
	 * @return the perceiving
	 */
	public int getPerceiving() {
		return perceiving;
	}

	/**
	 * @param perceiving the perceiving to set
	 */
	public void setPerceiving(int perceiving) {
		this.perceiving = perceiving;
	}

	/**
	 * @return the sensing
	 */
	public int getSensing() {
		return sensing;
	}

	/**
	 * @param sensing the sensing to set
	 */
	public void setSensing(int sensing) {
		this.sensing = sensing;
	}

	/**
	 * @return the intution
	 */
	public int getIntution() {
		return intution;
	}

	/**
	 * @param intution the intution to set
	 */
	public void setIntution(int intution) {
		this.intution = intution;
	}

	
}
